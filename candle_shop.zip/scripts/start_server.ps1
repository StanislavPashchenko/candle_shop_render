$env:POSTGRES_DB='candle_shop'
$env:POSTGRES_USER='postgres'
$env:POSTGRES_PASSWORD='linaga123'
$env:POSTGRES_HOST='127.0.0.1'
$env:POSTGRES_PORT='5432'
& 'C:/Users/snoby/Desktop/candle_shop/venv/Scripts/python.exe' manage.py runserver 0.0.0.0:8000
